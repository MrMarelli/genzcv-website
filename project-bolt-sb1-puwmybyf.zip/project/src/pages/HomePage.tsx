import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Award, BarChart } from 'lucide-react';
import HeroSection from '../components/sections/HeroSection';
import FeatureCard from '../components/ui/FeatureCard';
import TestimonialCarousel from '../components/sections/TestimonialCarousel';
import CTASection from '../components/sections/CTASection';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: <CheckCircle2 className="w-10 h-10 text-teal-600" />,
      title: "CV Workshops",
      description: "Professional guidance to create standout CVs that get noticed by employers."
    },
    {
      icon: <Award className="w-10 h-10 text-teal-600" />,
      title: "Interview Training",
      description: "Master the art of interviews with personalized coaching sessions."
    },
    {
      icon: <BarChart className="w-10 h-10 text-teal-600" />,
      title: "AI CV Generator",
      description: "Create a professional CV in minutes with our AI-powered tool."
    }
  ];

  const testimonials = [
    {
      quote: "GenZCV helped me land my dream internship at a tech company. The CV workshop was exactly what I needed!",
      author: "Jamie K.",
      position: "Marketing Intern",
      image: "https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "The interview training gave me confidence I never knew I had. I aced my first job interview!",
      author: "Alex T.",
      position: "Junior Developer",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "The AI tool created a CV that perfectly highlighted my skills. I got three callbacks in one week!",
      author: "Sam R.",
      position: "Design Graduate",
      image: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150"
    }
  ];

  return (
    <div className="w-full">
      <HeroSection 
        title="Launch Your Career With Confidence"
        subtitle="Bridging the gap between digital skills and employment opportunities for Gen Z"
        cta="Book a Free Consultation"
        ctaLink="/book"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How We Help</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We provide the tools and training you need to stand out in today's competitive job market.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard 
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/services" className="inline-flex items-center text-teal-600 font-semibold hover:text-teal-700 transition duration-300">
              Explore Our Services
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              See how we've helped young professionals launch their careers.
            </p>
          </div>
          
          <TestimonialCarousel testimonials={testimonials} />
        </div>
      </section>
      
      <CTASection 
        title="Ready to jumpstart your career?"
        description="Book a free consultation call to discuss how we can help you achieve your professional goals."
        buttonText="Book Now"
        buttonLink="/book"
      />
    </div>
  );
};

export default HomePage;