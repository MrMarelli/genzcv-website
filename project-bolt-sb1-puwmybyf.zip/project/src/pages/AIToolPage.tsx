import React, { useState } from 'react';
import { FileText, Download, ArrowRight, RefreshCw } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import CVForm from '../components/ai-tool/CVForm';
import CVPreview from '../components/ai-tool/CVPreview';
import CTASection from '../components/sections/CTASection';

const AIToolPage: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCV, setGeneratedCV] = useState<null | Record<string, any>>(null);
  
  const handleFormSubmit = (formData: any) => {
    setIsGenerating(true);
    
    // Simulate AI generation (would connect to actual API in production)
    setTimeout(() => {
      setGeneratedCV({
        ...formData,
        generatedSummary: `A motivated ${formData.jobTitle} with ${formData.yearsExperience} years of experience in ${formData.industry}. Strong skills in ${formData.skills} with a passion for delivering high-quality work. A graduate of ${formData.education} seeking to leverage my skills in a challenging role.`
      });
      setIsGenerating(false);
    }, 2000);
  };
  
  const handleDownload = () => {
    // In a real implementation, this would generate a PDF
    alert('In the full version, this would download your CV as a PDF.');
  };
  
  const handleReset = () => {
    setGeneratedCV(null);
  };
  
  return (
    <div className="w-full">
      <PageHeader 
        title="AI CV Generator" 
        subtitle="Create a professional CV in minutes"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          {!generatedCV ? (
            <div className="max-w-3xl mx-auto">
              <div className="mb-8 text-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-3">Enter Your Information</h2>
                <p className="text-gray-600">
                  Fill in the form below and our AI will generate a professional CV tailored to your experience.
                </p>
              </div>
              
              <CVForm 
                onSubmit={handleFormSubmit} 
                isSubmitting={isGenerating} 
              />
            </div>
          ) : (
            <div>
              <div className="mb-8 text-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-3">Your Generated CV</h2>
                <p className="text-gray-600">
                  Here's your professional CV generated based on your information.
                </p>
              </div>
              
              <div className="grid md:grid-cols-5 gap-8">
                <div className="md:col-span-3">
                  <CVPreview cv={generatedCV} />
                </div>
                
                <div className="md:col-span-2">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">CV Options</h3>
                    
                    <div className="space-y-4">
                      <button 
                        className="w-full py-3 bg-teal-600 text-white rounded-md font-medium hover:bg-teal-700 transition duration-300 flex items-center justify-center"
                        onClick={handleDownload}
                      >
                        <Download className="w-5 h-5 mr-2" />
                        Download CV
                      </button>
                      
                      <button 
                        className="w-full py-3 bg-white text-gray-700 rounded-md font-medium border border-gray-300 hover:bg-gray-50 transition duration-300 flex items-center justify-center"
                        onClick={handleReset}
                      >
                        <RefreshCw className="w-5 h-5 mr-2" />
                        Create New CV
                      </button>
                      
                      <div className="pt-4 border-t border-gray-200">
                        <h4 className="font-medium text-gray-700 mb-3">Want expert help?</h4>
                        <p className="text-gray-600 text-sm mb-4">
                          For a personalized CV review and professional guidance, book a CV workshop with our experts.
                        </p>
                        <a 
                          href="/book" 
                          className="w-full py-2 bg-white text-teal-600 border border-teal-600 rounded-md font-medium hover:bg-teal-50 transition duration-300 flex items-center justify-center"
                        >
                          Book CV Workshop
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
      
      <CTASection 
        title="Need personalized guidance?"
        description="Our CV workshops provide one-on-one coaching to help you create a truly standout CV."
        buttonText="Book a Workshop"
        buttonLink="/book"
      />
    </div>
  );
};

export default AIToolPage;