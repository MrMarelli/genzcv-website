import React from 'react';
import { Users, Award, Target, Book } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import CTASection from '../components/sections/CTASection';

const AboutPage: React.FC = () => {
  const teamMembers = [
    {
      name: "Alex Thompson",
      position: "Founder & Career Coach",
      bio: "With 10+ years of experience in recruitment and HR, Alex founded GenZCV to help bridge the gap between young talent and employers.",
      image: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=300"
    },
    {
      name: "Jamie Wilson",
      position: "CV Specialist",
      bio: "Jamie has helped over 500 clients land interviews at top companies through strategic CV optimization and personal branding.",
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300"
    },
    {
      name: "Sam Rivera",
      position: "Interview Coach",
      bio: "Former recruiter turned coach, Sam specializes in preparing candidates for technical and behavioral interviews.",
      image: "https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=300"
    }
  ];
  
  const values = [
    {
      icon: <Users className="w-10 h-10 text-teal-600" />,
      title: "Client-Centered",
      description: "We prioritize your unique needs and goals above all else. Our services are fully personalized to help you achieve your specific career aspirations."
    },
    {
      icon: <Award className="w-10 h-10 text-teal-600" />,
      title: "Excellence",
      description: "We're committed to delivering the highest quality service in every interaction. Our team stays current with industry trends to provide cutting-edge advice."
    },
    {
      icon: <Target className="w-10 h-10 text-teal-600" />,
      title: "Results-Driven",
      description: "We measure our success by your outcomes. Our approach focuses on actionable strategies that lead to interviews, offers, and career advancement."
    },
    {
      icon: <Book className="w-10 h-10 text-teal-600" />,
      title: "Continuous Learning",
      description: "We believe in equipping you with skills and knowledge that extend beyond landing a job to building a successful, fulfilling career."
    }
  ];
  
  return (
    <div className="w-full">
      <PageHeader 
        title="About GenZCV" 
        subtitle="Our mission is to help Gen Z thrive in the digital workplace"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                GenZCV was founded in 2024 with a clear purpose: to address the growing gap between the digital skills of young professionals and the evolving demands of employers.
              </p>
              <p className="text-gray-700 mb-4">
                We recognized that while Gen Z is the most digitally native generation, many struggle to effectively showcase their skills and experiences in ways that resonate with employers. At the same time, employers are facing a shortage of properly prepared candidates for digital roles.
              </p>
              <p className="text-gray-700">
                Our team of career specialists, recruiters, and industry experts came together to create a comprehensive solution - offering personalized CV workshops, interview training, and innovative tools that help young professionals present themselves effectively and confidently in the job market.
              </p>
            </div>
            
            <div className="relative">
              <div className="absolute -left-4 -top-4 w-24 h-24 bg-teal-100 rounded-lg z-0"></div>
              <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-teal-100 rounded-lg z-0"></div>
              <img 
                src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1000"
                alt="Team collaboration"
                className="rounded-lg shadow-lg relative z-10"
              />
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These core principles guide everything we do at GenZCV
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="inline-block p-3 bg-teal-50 rounded-lg mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Dedicated professionals committed to helping you succeed
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200">
                <img 
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover object-center"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-teal-600 font-medium mb-4">{member.position}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Impact</h2>
          
          <div className="grid grid-cols-3 gap-8 mb-12">
            <div>
              <p className="text-4xl font-bold text-teal-600 mb-2">500+</p>
              <p className="text-gray-700">CV Workshops Conducted</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-teal-600 mb-2">85%</p>
              <p className="text-gray-700">Interview Success Rate</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-teal-600 mb-2">12</p>
              <p className="text-gray-700">Industry Partnerships</p>
            </div>
          </div>
          
          <blockquote className="text-xl italic text-gray-700 mb-4">
            "Our mission goes beyond helping individuals find jobs. We're building a movement to empower an entire generation with the skills, confidence, and opportunities they need to thrive in the digital economy."
          </blockquote>
          <p className="font-medium text-gray-900">— Alex Thompson, Founder</p>
        </div>
      </section>
      
      <CTASection 
        title="Ready to work with our team?"
        description="Book a free consultation to discuss how we can help you achieve your career goals."
        buttonText="Book a Consultation"
        buttonLink="/book"
      />
    </div>
  );
};

export default AboutPage;