import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import BookingCalendar from '../components/booking/BookingCalendar';
import ServiceSelector from '../components/booking/ServiceSelector';
import TimeSlotSelector from '../components/booking/TimeSlotSelector';
import BookingForm from '../components/booking/BookingForm';

const BookingPage: React.FC = () => {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');
  
  const services = [
    { id: 'cv-workshop', name: 'CV Workshop', price: '£99' },
    { id: 'interview-training', name: 'Interview Training', price: '£129' },
    { id: 'career-starter', name: 'Career Starter Package', price: '£199' }
  ];
  
  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId);
    setStep(2);
  };
  
  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setStep(3);
  };
  
  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep(4);
  };
  
  const handleBookingSubmit = (formData: any) => {
    // In a real implementation, this would send the booking data to a server
    console.log('Booking submitted:', {
      service: selectedService,
      date: selectedDate,
      time: selectedTime,
      ...formData
    });
    setStep(5);
  };
  
  return (
    <div className="w-full">
      <PageHeader 
        title="Book Your Session" 
        subtitle="Simple booking in just a few clicks"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="mb-10">
            <div className="flex justify-between items-center w-full mb-8">
              <div className={`flex flex-col items-center ${step >= 1 ? 'text-teal-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${step >= 1 ? 'border-teal-600 bg-teal-50' : 'border-gray-300'} mb-2`}>
                  {step > 1 ? <CheckCircle className="w-5 h-5" /> : 1}
                </div>
                <span className="text-sm font-medium">Service</span>
              </div>
              <div className="flex-grow border-t border-gray-300 mx-4"></div>
              <div className={`flex flex-col items-center ${step >= 2 ? 'text-teal-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${step >= 2 ? 'border-teal-600 bg-teal-50' : 'border-gray-300'} mb-2`}>
                  {step > 2 ? <CheckCircle className="w-5 h-5" /> : 2}
                </div>
                <span className="text-sm font-medium">Date</span>
              </div>
              <div className="flex-grow border-t border-gray-300 mx-4"></div>
              <div className={`flex flex-col items-center ${step >= 3 ? 'text-teal-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${step >= 3 ? 'border-teal-600 bg-teal-50' : 'border-gray-300'} mb-2`}>
                  {step > 3 ? <CheckCircle className="w-5 h-5" /> : 3}
                </div>
                <span className="text-sm font-medium">Time</span>
              </div>
              <div className="flex-grow border-t border-gray-300 mx-4"></div>
              <div className={`flex flex-col items-center ${step >= 4 ? 'text-teal-600' : 'text-gray-400'}`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${step >= 4 ? 'border-teal-600 bg-teal-50' : 'border-gray-300'} mb-2`}>
                  {step > 4 ? <CheckCircle className="w-5 h-5" /> : 4}
                </div>
                <span className="text-sm font-medium">Details</span>
              </div>
            </div>
          </div>
          
          {step === 1 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Select a Service</h3>
              <ServiceSelector 
                services={services} 
                onSelect={handleServiceSelect} 
              />
            </div>
          )}
          
          {step === 2 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-teal-600" />
                Select a Date
              </h3>
              <BookingCalendar onDateSelect={handleDateSelect} />
              <div className="mt-4 flex justify-between">
                <button 
                  className="px-4 py-2 text-teal-600 hover:text-teal-700 font-medium"
                  onClick={() => setStep(1)}
                >
                  Back
                </button>
              </div>
            </div>
          )}
          
          {step === 3 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Clock className="w-5 h-5 mr-2 text-teal-600" />
                Select a Time
              </h3>
              <TimeSlotSelector 
                date={selectedDate} 
                onTimeSelect={handleTimeSelect} 
              />
              <div className="mt-4 flex justify-between">
                <button 
                  className="px-4 py-2 text-teal-600 hover:text-teal-700 font-medium"
                  onClick={() => setStep(2)}
                >
                  Back
                </button>
              </div>
            </div>
          )}
          
          {step === 4 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Your Details</h3>
              <div className="bg-gray-50 p-4 rounded-md mb-6">
                <h4 className="font-medium text-gray-700 mb-2">Booking Summary</h4>
                <p className="text-gray-600">
                  <strong>Service:</strong> {services.find(s => s.id === selectedService)?.name}
                </p>
                <p className="text-gray-600">
                  <strong>Date:</strong> {selectedDate?.toLocaleDateString()}
                </p>
                <p className="text-gray-600">
                  <strong>Time:</strong> {selectedTime}
                </p>
              </div>
              <BookingForm onSubmit={handleBookingSubmit} />
              <div className="mt-4 flex justify-between">
                <button 
                  className="px-4 py-2 text-teal-600 hover:text-teal-700 font-medium"
                  onClick={() => setStep(3)}
                >
                  Back
                </button>
              </div>
            </div>
          )}
          
          {step === 5 && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Booking Confirmed!</h3>
              <p className="text-gray-600 mb-6">
                We've sent a confirmation email with all the details. Looking forward to working with you!
              </p>
              <div className="bg-gray-50 p-4 rounded-md mb-6 text-left max-w-md mx-auto">
                <h4 className="font-medium text-gray-700 mb-2">Your Booking</h4>
                <p className="text-gray-600">
                  <strong>Service:</strong> {services.find(s => s.id === selectedService)?.name}
                </p>
                <p className="text-gray-600">
                  <strong>Date:</strong> {selectedDate?.toLocaleDateString()}
                </p>
                <p className="text-gray-600">
                  <strong>Time:</strong> {selectedTime}
                </p>
              </div>
              <button 
                className="px-6 py-3 bg-teal-600 text-white rounded-md font-medium hover:bg-teal-700 transition duration-300"
                onClick={() => window.location.href = '/'}
              >
                Return to Home
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default BookingPage;