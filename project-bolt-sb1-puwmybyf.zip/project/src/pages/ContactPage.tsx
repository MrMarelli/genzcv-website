import React from 'react';
import { Mail, MapPin, Phone, MessageSquare } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';

const ContactPage: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Would handle form submission in a real implementation
    alert('Message sent! (This is just a demo implementation)');
  };
  
  return (
    <div className="w-full">
      <PageHeader 
        title="Contact Us" 
        subtitle="We'd love to hear from you. Get in touch with our team."
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-4">
                <Phone className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Call Us</h3>
              <p className="text-gray-600 mb-2">Mon-Fri: 9am to 5pm</p>
              <a href="tel:+442012345678" className="text-teal-600 font-medium hover:text-teal-700 transition-colors">
                +44 20 1234 5678
              </a>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-4">
                <Mail className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Us</h3>
              <p className="text-gray-600 mb-2">We'll respond within 24 hours</p>
              <a href="mailto:hello@genzcv.com" className="text-teal-600 font-medium hover:text-teal-700 transition-colors">
                hello@genzcv.com
              </a>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Visit Us</h3>
              <p className="text-gray-600 mb-2">For in-person consultations</p>
              <address className="text-teal-600 font-medium not-italic">
                123 Tech Hub, London EC1V
              </address>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                    required
                  />
                </div>
                
                <div>
                  <button
                    type="submit"
                    className="py-3 px-6 bg-teal-600 text-white rounded-md font-medium hover:bg-teal-700 transition duration-300 inline-flex items-center"
                  >
                    <MessageSquare className="w-5 h-5 mr-2" />
                    Send Message
                  </button>
                </div>
              </form>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">How do your sessions work?</h3>
                  <p className="text-gray-600">
                    All our sessions are conducted online via Zoom. After booking, you'll receive a confirmation email with a link to join your session at the scheduled time.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">What should I prepare for my first session?</h3>
                  <p className="text-gray-600">
                    For CV workshops, please have your current CV ready. For interview training, prepare a list of companies or roles you're targeting. For the best experience, ensure you have a stable internet connection.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Do you offer refunds?</h3>
                  <p className="text-gray-600">
                    Yes, we offer a 100% satisfaction guarantee. If you're not happy with your session, we'll refund your payment or offer a complimentary follow-up session.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Can I reschedule my session?</h3>
                  <p className="text-gray-600">
                    Yes, you can reschedule up to 24 hours before your session without any charge. Simply contact us via email or phone to arrange a new time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;