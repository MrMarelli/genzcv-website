import React from 'react';
import { ArrowRight, Search, Filter } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import CTASection from '../components/sections/CTASection';

const ResourcesPage: React.FC = () => {
  const resources = [
    {
      title: "10 CV Mistakes That Cost You Job Interviews",
      category: "CV Tips",
      date: "June 15, 2025",
      image: "https://images.pexels.com/photos/1181622/pexels-photo-1181622.jpeg?auto=compress&cs=tinysrgb&w=500"
    },
    {
      title: "How to Answer the 'Tell Me About Yourself' Question",
      category: "Interview Tips",
      date: "June 10, 2025",
      image: "https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg?auto=compress&cs=tinysrgb&w=500"
    },
    {
      title: "Using AI Tools to Enhance Your Job Search",
      category: "Technology",
      date: "June 5, 2025",
      image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=500"
    },
    {
      title: "The Digital Skills Every Gen Z Jobseeker Needs",
      category: "Career Development",
      date: "May 28, 2025",
      image: "https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=500"
    },
    {
      title: "Navigating Remote Work Interviews",
      category: "Interview Tips",
      date: "May 20, 2025",
      image: "https://images.pexels.com/photos/4226122/pexels-photo-4226122.jpeg?auto=compress&cs=tinysrgb&w=500"
    },
    {
      title: "Building Your Personal Brand on LinkedIn",
      category: "Networking",
      date: "May 15, 2025",
      image: "https://images.pexels.com/photos/3184405/pexels-photo-3184405.jpeg?auto=compress&cs=tinysrgb&w=500"
    }
  ];
  
  return (
    <div className="w-full">
      <PageHeader 
        title="Career Resources" 
        subtitle="Free guides, articles, and templates to help you succeed"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between mb-8">
            <div className="relative mb-4 md:mb-0 md:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input 
                type="text"
                className="pl-10 block w-full rounded-md border border-gray-300 py-2 px-3 shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                placeholder="Search resources..."
              />
            </div>
            
            <div className="flex space-x-2">
              <button className="flex items-center px-3 py-2 rounded border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </button>
              
              <select className="block w-40 rounded-md border border-gray-300 py-2 px-3 shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500">
                <option>All Categories</option>
                <option>CV Tips</option>
                <option>Interview Tips</option>
                <option>Career Development</option>
                <option>Technology</option>
                <option>Networking</option>
              </select>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {resources.map((resource, index) => (
              <div 
                key={index}
                className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
              >
                <img 
                  src={resource.image}
                  alt={resource.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-semibold px-2 py-1 bg-teal-100 text-teal-800 rounded">
                      {resource.category}
                    </span>
                    <span className="text-xs text-gray-500">{resource.date}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">
                    {resource.title}
                  </h3>
                  <a 
                    href="#" 
                    className="inline-flex items-center text-teal-600 font-medium hover:text-teal-700 transition-colors"
                  >
                    Read More <ArrowRight className="ml-2 w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex justify-center mt-12">
            <button className="px-5 py-2 bg-white text-teal-600 border border-teal-600 rounded-md font-medium hover:bg-teal-50 transition-colors">
              Load More Resources
            </button>
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Free CV Templates</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Download our professionally designed CV templates to give your job application a head start.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((template) => (
              <div 
                key={template}
                className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 hover:shadow-md transition-shadow p-6"
              >
                <div className="h-64 bg-gray-100 mb-4 overflow-hidden rounded flex items-center justify-center">
                  <img 
                    src={`https://images.pexels.com/photos/636${150 + template}/pexels-photo-636${150 + template}.jpeg?auto=compress&cs=tinysrgb&w=500`}
                    alt={`CV Template ${template}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">
                  Professional Template {template}
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Clean, modern design perfect for {
                    template === 1 ? 'creative roles' : 
                    template === 2 ? 'corporate positions' : 
                    'technical careers'
                  }.
                </p>
                <button className="w-full py-2 bg-teal-600 text-white rounded-md font-medium hover:bg-teal-700 transition-colors">
                  Download Template
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <CTASection 
        title="Ready for personalized career guidance?"
        description="Take advantage of our expert services to stand out in today's competitive job market."
        buttonText="Book a Session"
        buttonLink="/book"
      />
    </div>
  );
};

export default ResourcesPage;