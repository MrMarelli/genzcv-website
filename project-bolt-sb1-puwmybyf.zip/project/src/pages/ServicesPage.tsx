import React from 'react';
import { FileText, Users, Lightbulb, CheckCircle } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import ServiceCard from '../components/ui/ServiceCard';
import PricingCard from '../components/ui/PricingCard';
import CTASection from '../components/sections/CTASection';

const ServicesPage: React.FC = () => {
  const services = [
    {
      icon: <FileText className="w-12 h-12 text-teal-600" />,
      title: "CV Workshops",
      description: "Our CV workshops provide personalized guidance to help you create a standout CV. We'll work with you to highlight your skills and experiences in a way that grabs employers' attention.",
      features: [
        "Personalized CV review and feedback",
        "Industry-specific formatting tips",
        "Keyword optimization for ATS systems",
        "One-on-one coaching session",
        "Follow-up support"
      ]
    },
    {
      icon: <Users className="w-12 h-12 text-teal-600" />,
      title: "Interview Training",
      description: "Master the art of interviewing with our comprehensive training sessions. From common questions to body language, we'll prepare you for every aspect of the interview process.",
      features: [
        "Mock interview sessions with feedback",
        "Industry-specific question preparation",
        "Body language and communication coaching",
        "Salary negotiation techniques",
        "Post-interview follow-up strategies"
      ]
    },
    {
      icon: <Lightbulb className="w-12 h-12 text-teal-600" />,
      title: "AI CV Generator",
      description: "Create a professional CV in minutes with our AI-powered tool. Simply input your information, and our system will generate a tailored CV that highlights your strengths.",
      features: [
        "Multiple template options",
        "Industry-specific keyword optimization",
        "Instant generation and downloads",
        "Unlimited edits and revisions",
        "ATS-friendly formatting"
      ]
    }
  ];

  const pricingPlans = [
    {
      title: "CV Workshop",
      price: "£99",
      description: "Perfect for crafting a standout CV",
      features: [
        "90-minute personalized session",
        "CV template selection",
        "Content optimization",
        "ATS optimization",
        "One revision after session"
      ],
      cta: "Book Now",
      ctaLink: "/book",
      popular: false
    },
    {
      title: "Career Starter",
      price: "£199",
      description: "Our most popular complete package",
      features: [
        "CV Workshop (90 minutes)",
        "Interview Training (90 minutes)",
        "LinkedIn Profile Optimization",
        "Email templates for outreach",
        "30-day email support"
      ],
      cta: "Book Now",
      ctaLink: "/book",
      popular: true
    },
    {
      title: "Interview Training",
      price: "£129",
      description: "Master the interview process",
      features: [
        "90-minute coaching session",
        "Mock interviews with feedback",
        "Industry-specific preparation",
        "Salary negotiation tactics",
        "Follow-up strategy session"
      ],
      cta: "Book Now",
      ctaLink: "/book",
      popular: false
    }
  ];
  
  return (
    <div className="w-full">
      <PageHeader 
        title="Our Services" 
        subtitle="Comprehensive career preparation services designed for Gen Z"
      />
      
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid gap-12">
            {services.map((service, index) => (
              <ServiceCard 
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                reverse={index % 2 !== 0}
              />
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Pricing Plans</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Choose the package that best suits your career goals
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <PricingCard 
                key={index}
                title={plan.title}
                price={plan.price}
                description={plan.description}
                features={plan.features}
                cta={plan.cta}
                ctaLink={plan.ctaLink}
                popular={plan.popular}
              />
            ))}
          </div>

          <div className="mt-12 flex items-center justify-center">
            <div className="flex items-center bg-teal-50 p-4 rounded-lg border border-teal-200">
              <CheckCircle className="w-6 h-6 text-teal-600 mr-3 flex-shrink-0" />
              <p className="text-gray-700">
                All packages include a <span className="font-semibold">100% satisfaction guarantee</span>. Not happy with our service? We'll refund your money.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <CTASection 
        title="Ready to invest in your future?"
        description="Book your service today and take the first step towards career success."
        buttonText="Book Now"
        buttonLink="/book"
      />
    </div>
  );
};

export default ServicesPage;