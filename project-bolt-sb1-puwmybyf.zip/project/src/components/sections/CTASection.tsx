import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface CTASectionProps {
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
}

const CTASection: React.FC<CTASectionProps> = ({ 
  title, 
  description, 
  buttonText, 
  buttonLink 
}) => {
  return (
    <section className="bg-teal-700 text-white py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-8 md:mb-0 md:mr-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {title}
            </h2>
            <p className="text-teal-100 md:text-lg max-w-xl">
              {description}
            </p>
          </div>
          
          <div className="flex-shrink-0">
            <Link
              to={buttonLink}
              className="inline-flex items-center px-8 py-4 bg-white text-teal-700 rounded-md font-medium text-lg hover:bg-gray-100 transition duration-300"
            >
              {buttonText}
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;