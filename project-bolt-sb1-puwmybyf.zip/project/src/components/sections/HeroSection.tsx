import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  title: string;
  subtitle: string;
  cta: string;
  ctaLink: string;
}

const HeroSection: React.FC<HeroSectionProps> = ({ title, subtitle, cta, ctaLink }) => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <section className="relative h-screen flex items-center min-h-[600px]">
      {/* Background image with overlay */}
      <div className="absolute inset-0 bg-cover bg-center bg-fixed" style={{ 
        backgroundImage: "url('https://images.pexels.com/photos/1181622/pexels-photo-1181622.jpeg?auto=compress&cs=tinysrgb&w=1920')",
      }}>
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 to-gray-900/40"></div>
      </div>
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div 
          className={`max-w-2xl transition-all duration-1000 transform ${
            isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
          }`}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            {title}
          </h1>
          <p className="text-xl text-gray-200 mb-8">
            {subtitle}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
            <Link
              to={ctaLink}
              className="px-8 py-4 bg-teal-600 rounded-md text-white font-medium text-lg hover:bg-teal-700 transition duration-300 inline-flex items-center justify-center"
            >
              {cta} <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <div className="text-gray-300 text-sm sm:ml-6 flex items-center">
              <span className="bg-teal-500/20 text-teal-300 text-xs py-1 px-2 rounded-md">
                FREE CONSULTATION
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-sm">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
          </svg>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;