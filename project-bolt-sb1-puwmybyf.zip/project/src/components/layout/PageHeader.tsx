import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle }) => {
  return (
    <section className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-16 mt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
          {subtitle && (
            <p className="text-lg text-gray-300">{subtitle}</p>
          )}
        </div>
      </div>
    </section>
  );
};

export default PageHeader;