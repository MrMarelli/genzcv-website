import React, { useState } from 'react';
import { CheckCircle } from 'lucide-react';

interface Service {
  id: string;
  name: string;
  price: string;
}

interface ServiceSelectorProps {
  services: Service[];
  onSelect: (serviceId: string) => void;
}

const ServiceSelector: React.FC<ServiceSelectorProps> = ({ services, onSelect }) => {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  
  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId);
  };
  
  const handleContinue = () => {
    if (selectedService) {
      onSelect(selectedService);
    }
  };
  
  return (
    <div>
      <div className="grid gap-4">
        {services.map(service => (
          <div
            key={service.id}
            onClick={() => handleServiceSelect(service.id)}
            className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
              selectedService === service.id
                ? 'border-teal-600 bg-teal-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">{service.name}</h4>
                <p className="text-teal-600 font-medium mt-1">{service.price}</p>
              </div>
              
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                selectedService === service.id
                  ? 'bg-teal-600 text-white'
                  : 'border-2 border-gray-300'
              }`}>
                {selectedService === service.id && (
                  <CheckCircle className="w-5 h-5" />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8">
        <button
          onClick={handleContinue}
          disabled={!selectedService}
          className={`w-full py-3 rounded-md font-medium transition-colors ${
            selectedService
              ? 'bg-teal-600 text-white hover:bg-teal-700'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
          }`}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default ServiceSelector;