import React, { useState } from 'react';
import { Clock } from 'lucide-react';

interface TimeSlotSelectorProps {
  date: Date | null;
  onTimeSelect: (time: string) => void;
}

const TimeSlotSelector: React.FC<TimeSlotSelectorProps> = ({ date, onTimeSelect }) => {
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  
  // Generate time slots (9 AM - 5 PM)
  const morningSlots = ['9:00 AM', '10:00 AM', '11:00 AM'];
  const afternoonSlots = ['1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'];
  
  // For demo purposes, make some random slots unavailable
  const isAvailable = (time: string) => {
    if (!date) return false;
    
    const day = date.getDate();
    const timeHour = parseInt(time.split(':')[0]);
    
    // Random availability based on date and time
    return !((day + timeHour) % 4 === 0);
  };
  
  const handleTimeClick = (time: string) => {
    setSelectedTime(time);
    onTimeSelect(time);
  };
  
  const renderTimeSlots = (slots: string[]) => {
    return slots.map(time => {
      const available = isAvailable(time);
      const selected = selectedTime === time;
      
      return (
        <button
          key={time}
          onClick={() => available && handleTimeClick(time)}
          disabled={!available}
          className={`py-3 px-4 rounded-md text-center transition-colors ${
            selected
              ? 'bg-teal-600 text-white'
              : available
              ? 'border border-gray-300 hover:border-teal-500 text-gray-800'
              : 'border border-gray-200 text-gray-300 cursor-not-allowed'
          }`}
        >
          <Clock className={`w-4 h-4 mr-2 ${selected ? 'text-white' : available ? 'text-teal-600' : 'text-gray-300'}`} />
          {time}
        </button>
      );
    });
  };
  
  return (
    <div>
      <p className="text-gray-600 mb-4">
        {date ? (
          <>Selected date: <span className="font-medium">{date.toLocaleDateString()}</span></>
        ) : (
          'Please select a date first'
        )}
      </p>
      
      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-800 mb-3">Morning</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {renderTimeSlots(morningSlots)}
        </div>
      </div>
      
      <div>
        <h4 className="text-sm font-medium text-gray-800 mb-3">Afternoon</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {renderTimeSlots(afternoonSlots)}
        </div>
      </div>
      
      <div className="mt-4 text-sm text-gray-500 flex items-center">
        <Clock className="w-4 h-4 mr-2 text-gray-400" />
        All sessions last 90 minutes
      </div>
    </div>
  );
};

export default TimeSlotSelector;