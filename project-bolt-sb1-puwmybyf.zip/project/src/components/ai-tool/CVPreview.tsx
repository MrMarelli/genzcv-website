import React from 'react';
import { Mail, Phone, Award, Briefcase, GraduationCap } from 'lucide-react';

interface CVPreviewProps {
  cv: Record<string, any>;
}

const CVPreview: React.FC<CVPreviewProps> = ({ cv }) => {
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-md overflow-hidden">
      <div className="bg-gray-800 text-white p-8">
        <h1 className="text-2xl font-bold mb-2">{cv.fullName}</h1>
        <h2 className="text-lg text-gray-300 mb-4">{cv.jobTitle}</h2>
        <p>{cv.generatedSummary}</p>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6 pb-6 border-b border-gray-200">
          {cv.email && (
            <div className="flex items-center mb-2 md:mb-0">
              <Mail className="w-4 h-4 mr-2 text-teal-600" />
              <span className="text-gray-800">{cv.email}</span>
            </div>
          )}
          
          {cv.phone && (
            <div className="flex items-center">
              <Phone className="w-4 h-4 mr-2 text-teal-600" />
              <span className="text-gray-800">{cv.phone}</span>
            </div>
          )}
        </div>
        
        <div className="mb-6 pb-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
            <Award className="w-5 h-5 mr-2 text-teal-600" />
            Skills
          </h3>
          
          <div className="flex flex-wrap gap-2">
            {cv.skills.split(',').map((skill: string, index: number) => (
              <span 
                key={index}
                className="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-sm"
              >
                {skill.trim()}
              </span>
            ))}
          </div>
        </div>
        
        {cv.workExperience && (
          <div className="mb-6 pb-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Briefcase className="w-5 h-5 mr-2 text-teal-600" />
              Work Experience
            </h3>
            
            <p className="text-gray-700">{cv.workExperience}</p>
          </div>
        )}
        
        {cv.education && (
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <GraduationCap className="w-5 h-5 mr-2 text-teal-600" />
              Education
            </h3>
            
            <p className="text-gray-700">{cv.education}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CVPreview;