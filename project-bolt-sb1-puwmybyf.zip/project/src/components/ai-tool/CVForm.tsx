import React, { useState } from 'react';
import { Briefcase, GraduationCap, Award, RefreshCw } from 'lucide-react';

interface CVFormProps {
  onSubmit: (formData: any) => void;
  isSubmitting: boolean;
}

const CVForm: React.FC<CVFormProps> = ({ onSubmit, isSubmitting }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    jobTitle: '',
    yearsExperience: '',
    industry: '',
    skills: '',
    education: '',
    workExperience: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    const requiredFields = ['fullName', 'email', 'jobTitle', 'skills'];
    
    requiredFields.forEach(field => {
      if (!formData[field as keyof typeof formData].trim()) {
        newErrors[field] = `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`;
      }
    });
    
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      onSubmit(formData);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Briefcase className="w-5 h-5 mr-2 text-teal-600" />
          Personal Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
              Full Name *
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              className={`block w-full rounded-md shadow-sm py-2 px-3 border ${
                errors.fullName ? 'border-red-500' : 'border-gray-300'
              } focus:outline-none focus:ring-teal-500 focus:border-teal-500`}
            />
            {errors.fullName && (
              <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              Email *
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`block w-full rounded-md shadow-sm py-2 px-3 border ${
                errors.email ? 'border-red-500' : 'border-gray-300'
              } focus:outline-none focus:ring-teal-500 focus:border-teal-500`}
            />
            {errors.email && (
              <p className="mt-1 text-sm text-red-600">{errors.email}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
              Phone
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            />
          </div>
        </div>
      </div>
      
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <GraduationCap className="w-5 h-5 mr-2 text-teal-600" />
          Professional Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700 mb-1">
              Current/Target Job Title *
            </label>
            <input
              type="text"
              id="jobTitle"
              name="jobTitle"
              value={formData.jobTitle}
              onChange={handleChange}
              className={`block w-full rounded-md shadow-sm py-2 px-3 border ${
                errors.jobTitle ? 'border-red-500' : 'border-gray-300'
              } focus:outline-none focus:ring-teal-500 focus:border-teal-500`}
              placeholder="e.g. Graphic Designer"
            />
            {errors.jobTitle && (
              <p className="mt-1 text-sm text-red-600">{errors.jobTitle}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="yearsExperience" className="block text-sm font-medium text-gray-700 mb-1">
              Years of Experience
            </label>
            <select
              id="yearsExperience"
              name="yearsExperience"
              value={formData.yearsExperience}
              onChange={handleChange}
              className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            >
              <option value="">Select...</option>
              <option value="0">Entry Level (0 years)</option>
              <option value="1-2">1-2 years</option>
              <option value="3-5">3-5 years</option>
              <option value="5+">5+ years</option>
            </select>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-1">
            Industry
          </label>
          <input
            type="text"
            id="industry"
            name="industry"
            value={formData.industry}
            onChange={handleChange}
            className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            placeholder="e.g. Technology, Marketing, Finance"
          />
        </div>
        
        <div>
          <label htmlFor="skills" className="block text-sm font-medium text-gray-700 mb-1">
            Key Skills *
          </label>
          <input
            type="text"
            id="skills"
            name="skills"
            value={formData.skills}
            onChange={handleChange}
            className={`block w-full rounded-md shadow-sm py-2 px-3 border ${
              errors.skills ? 'border-red-500' : 'border-gray-300'
            } focus:outline-none focus:ring-teal-500 focus:border-teal-500`}
            placeholder="e.g. Adobe Photoshop, JavaScript, Project Management"
          />
          {errors.skills && (
            <p className="mt-1 text-sm text-red-600">{errors.skills}</p>
          )}
        </div>
      </div>
      
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Award className="w-5 h-5 mr-2 text-teal-600" />
          Education & Experience
        </h3>
        
        <div className="mb-4">
          <label htmlFor="education" className="block text-sm font-medium text-gray-700 mb-1">
            Education
          </label>
          <textarea
            id="education"
            name="education"
            rows={3}
            value={formData.education}
            onChange={handleChange}
            className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            placeholder="e.g. Bachelor's in Computer Science, University of Oxford (2020-2023)"
          />
        </div>
        
        <div>
          <label htmlFor="workExperience" className="block text-sm font-medium text-gray-700 mb-1">
            Work Experience
          </label>
          <textarea
            id="workExperience"
            name="workExperience"
            rows={5}
            value={formData.workExperience}
            onChange={handleChange}
            className="block w-full rounded-md shadow-sm py-2 px-3 border border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500"
            placeholder="e.g. Marketing Assistant at ABC Company (2022-2023). Managed social media accounts and assisted with campaigns."
          />
        </div>
      </div>
      
      <div className="p-6">
        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full py-3 rounded-md font-medium flex items-center justify-center ${
            isSubmitting 
              ? 'bg-gray-300 text-gray-700 cursor-not-allowed' 
              : 'bg-teal-600 text-white hover:bg-teal-700'
          } transition duration-300`}
        >
          {isSubmitting ? (
            <>
              <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
              Generating CV...
            </>
          ) : (
            'Generate My CV'
          )}
        </button>
      </div>
    </form>
  );
};

export default CVForm;