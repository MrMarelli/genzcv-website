import React from 'react';
import { Check } from 'lucide-react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  reverse?: boolean;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  icon, 
  title, 
  description, 
  features,
  reverse = false 
}) => {
  return (
    <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} gap-8 items-center`}>
      <div className="md:w-1/2">
        <div className="bg-gray-50 p-8 rounded-xl flex flex-col items-center md:items-center border border-gray-200">
          {icon}
          <h3 className="text-2xl font-bold text-gray-900 mt-4 mb-2 text-center">{title}</h3>
          <div className="w-16 h-1 bg-teal-600 rounded-full mb-4"></div>
          <img 
            src={`https://images.pexels.com/photos/${
              title === "CV Workshops" ? "1181605" : 
              title === "Interview Training" ? "5699432" : "8867434"
            }/pexels-photo-${
              title === "CV Workshops" ? "1181605" : 
              title === "Interview Training" ? "5699432" : "8867434"
            }.jpeg?auto=compress&cs=tinysrgb&w=600`} 
            alt={title}
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
        </div>
      </div>
      <div className="md:w-1/2">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        <ul className="space-y-3">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-teal-100 flex items-center justify-center mt-0.5">
                <Check className="w-4 h-4 text-teal-600" />
              </div>
              <span className="ml-3 text-gray-600">{feature}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ServiceCard;