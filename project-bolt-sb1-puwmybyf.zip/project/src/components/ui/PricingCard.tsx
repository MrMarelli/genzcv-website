import React from 'react';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

interface PricingCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  cta: string;
  ctaLink: string;
  popular?: boolean;
}

const PricingCard: React.FC<PricingCardProps> = ({
  title,
  price,
  description,
  features,
  cta,
  ctaLink,
  popular = false
}) => {
  return (
    <div 
      className={`rounded-lg overflow-hidden ${
        popular 
          ? 'border-2 border-teal-600 relative transform md:-translate-y-4 shadow-lg' 
          : 'border border-gray-200 shadow-sm'
      }`}
    >
      {popular && (
        <div className="bg-teal-600 text-white py-1 px-4 text-xs font-bold uppercase tracking-wider text-center">
          Most Popular
        </div>
      )}
      
      <div className="p-6 md:p-8 bg-white">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="mb-6">
          <span className="text-3xl font-bold text-gray-900">{price}</span>
        </div>
        
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <div className={`flex-shrink-0 w-5 h-5 rounded-full ${popular ? 'bg-teal-100' : 'bg-gray-100'} flex items-center justify-center mt-0.5`}>
                <Check className={`w-3 h-3 ${popular ? 'text-teal-600' : 'text-gray-600'}`} />
              </div>
              <span className="ml-3 text-gray-600 text-sm">{feature}</span>
            </li>
          ))}
        </ul>
        
        <Link
          to={ctaLink}
          className={`block w-full py-3 px-4 text-center rounded-md font-medium ${
            popular 
              ? 'bg-teal-600 text-white hover:bg-teal-700' 
              : 'bg-white text-teal-600 border border-teal-600 hover:bg-teal-50'
          } transition duration-300`}
        >
          {cta}
        </Link>
      </div>
    </div>
  );
};

export default PricingCard;